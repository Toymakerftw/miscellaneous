/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.toymaker.dao;
import java.sql.*;  
import java.util.*;
import com.toymaker.bean.User;  
/**
 *
 * @author toymaker
 */
public class UserDao {
    
    public static Connection getConnection(){  
    Connection con=null;  
    try{  
        Class.forName("com.mysql.jdbc.Driver");  
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydairy","root","password");  
    }catch(Exception e){System.out.println(e);}  
    return con;  
}  
   
    public static int save(User u){  
    int status=0;  
    try{  
        Connection con=getConnection();  
        PreparedStatement ps=con.prepareStatement("insert into user432(NAME,EMAIL,PASS) values(?,?,?)");  
        ps.setString(1,u.getNAME());  
        ps.setString(2,u.getPASS());  
        ps.setString(3,u.getEMAIL());   
        status=ps.executeUpdate();  
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    return status;  
}  
    
}
