/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.toymaker.bean;

/**
 *
 * @author toymaker
 */
public class User {
	private String NAME,EMAIL,PASS;

    public String getNAME() {
        return NAME;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public String getPASS() {
        return PASS;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public void setPASS(String PASS) {
        this.PASS = PASS;
    }	
}
